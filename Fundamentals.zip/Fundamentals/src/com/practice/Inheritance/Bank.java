package com.practice.Inheritance;

public class Bank extends RBI implements Icici {

	public void m2() {

	}

	public static void main(String[] args) {
		Bank b = new Bank(); // This object will have Axis class properties also. So you can call m1()
		b.m1(); // and m2() of itself
		b.m2();

		Axis a = new Axis(); // Will have only Axis properties.So you can use m1()
		a.m1(); // and You can't use m2() because Object created only for Axis(Child)
		// a.m2();

		Axis a1 = new Bank(); // Created object for Bank class but referenced to Axis(Child).
		a1.m1(); // So you can access only Axis(Child)methods. You can't access parent
		// a1.m2();

		// Bank b1 = new Axis(); //You can't create the Object by referencing to the
		// parent class

	}

}

class Axis {
	public void m1() {
		System.out.println("Axis");
	}

}

interface Icici {

}

class RBI extends Axis {
	public void m1() {
		System.out.println("RBI");		//Here RBI is the child of Axis. So, m1() method replace with current m1() implementation
	}
}
