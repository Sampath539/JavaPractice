package com.Thread;

public class ThreadConstructors {

	/*
	 * Thread t = new Thread();
	 * 			Thread(Runnable r), Thread(String name)--To give name for Thread, Thread(Runnable r, String name)
	 * Thread(ThreadGroup tg, String name)--we can maintain ThreadGroups, Thread(ThreadGroup tg, Runnable r)
	 * Thread(ThreadGroup tg, Runnable r, String name), Thread(ThreadGroup tg, Runnable r, String name, long stackSize)
	 * 
	*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
