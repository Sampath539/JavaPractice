package com.java;

public class Q83 {

	public static void main(String[] args) {
		int[] x = {6,9,11};
		for(int a: x) {
			System.out.println(a);
			a++;
			//System.out.print(a);
		}

	}

}
